package com.example.quotexsignal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class Candle(
    val startMs: Long, val open: Double, var high: Double,
    var low: Double, var close: Double
)

enum class Signal { UP, DOWN, NO_TRADE }

data class SignalResult(val signal: Signal, val confidence: Int, val reason: String)

class LiveFeed(private val onPrice: (Double, Long) -> Unit, private val onStatus: (String) -> Unit) {
    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS).build()
    private var ws: WebSocket? = null

    fun connect(apiKey: String, symbols: String) {
        if (apiKey.isBlank()) {
            onStatus("API key required")
            return
        }
        val url = "wss://ws.twelvedata.com/v1/quotes/price?apikey=$apiKey"
        val req = Request.Builder().url(url).build()
        ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val body = JSONObject()
                    .put("action", "subscribe")
                    .put("params", JSONObject().put("symbols", symbols))
                webSocket.send(body.toString())
                onStatus("LIVE connected")
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val j = JSONObject(text)
                    if (j.has("price")) {
                        val price = j.optDouble("price", Double.NaN)
                        val ts = if (j.has("timestamp")) j.optLong("timestamp") * 1000L
                                 else System.currentTimeMillis()
                        if (price.isFinite()) onPrice(price, ts)
                    }
                } catch (_: Exception) {}
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                onStatus("Disconnected: ${t.message ?: "network error"}")
            }
        })
    }
    fun close() { ws?.close(1000, "user closed") }
}

object SignalEngine {
    fun analyze(c: List<Candle>): SignalResult {
        if (c.size < 30) return SignalResult(Signal.NO_TRADE, 0, "Waiting for 30 candles")
        val x = c.map { it.close }
        val fast = ema(x, 9); val slow = ema(x, 21); val r = rsi(x, 14)
        val roc = (x.last() - x[x.size - 6]) / x[x.size - 6] * 100
        var s = 0
        if (fast > slow) s += 2 else s -= 2
        if (r in 52.0..70.0) s++
        if (r in 30.0..48.0) s--
        if (roc > 0.02) s++ else if (roc < -0.02) s--
        return when {
            s >= 3 -> SignalResult(Signal.UP, min(95, 50 + abs(s)*9), "EMA + RSI + momentum bullish")
            s <= -3 -> SignalResult(Signal.DOWN, min(95, 50 + abs(s)*9), "EMA + RSI + momentum bearish")
            else -> SignalResult(Signal.NO_TRADE, 50, "Weak / conflicting setup")
        }
    }
    private fun ema(x: List<Double>, n: Int): Double {
        val k = 2.0/(n+1); var e = x.take(n).average()
        for (i in n until x.size) e = x[i]*k + e*(1-k)
        return e
    }
    private fun rsi(x: List<Double>, n: Int): Double {
        var g=0.0; var l=0.0
        for (i in x.size-n until x.size) {
            val d=x[i]-x[i-1]; if(d>=0) g+=d else l-=d
        }
        if(l==0.0) return 100.0
        val rs=(g/n)/(l/n); return 100-100/(1+rs)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LiveSignalApp() }
    }
}

@Composable
fun LiveSignalApp() {
    val pairs = listOf("EUR/USD","GBP/USD","AUD/USD","USD/JPY","EUR/JPY","USD/CAD","NZD/USD")
    val frames = listOf(15L,30L,60L,120L,180L,300L)
    val expiry = listOf("10s","15s","30s","1m")
    var pair by remember { mutableStateOf("AUD/USD") }
    var frame by remember { mutableStateOf(15L) }
    var exp by remember { mutableStateOf("30s") }
    var key by remember { mutableStateOf("") }
    var live by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("OFFLINE") }
    var lastPrice by remember { mutableStateOf<Double?>(null) }
    var candles by remember { mutableStateOf(emptyList<Candle>()) }
    var result by remember { mutableStateOf(SignalResult(Signal.NO_TRADE,0,"Connect live feed")) }
    val feed = remember {
        LiveFeed(
            onPrice = { price, ts ->
                lastPrice = price
                val bucket = (ts / (frame*1000L)) * (frame*1000L)
                val current = candles.toMutableList()
                if (current.isEmpty() || current.last().startMs != bucket) {
                    current.add(Candle(bucket,price,price,price,price))
                } else {
                    val c=current.last(); c.high=max(c.high,price); c.low=min(c.low,price); c.close=price
                }
                candles=current.takeLast(200)
                result=SignalEngine.analyze(candles)
            },
            onStatus = { status=it }
        )
    }
    DisposableEffect(Unit) { onDispose { feed.close() } }

    MaterialTheme(colorScheme=darkColorScheme()) {
        Scaffold(topBar={ TopAppBar(title={Text("Signal Bot • LIVE / DEMO")}) }) { pad ->
            LazyColumn(
                modifier=Modifier.fillMaxSize().padding(pad).padding(16.dp),
                verticalArrangement=Arrangement.spacedBy(12.dp)
            ) {
                item { Text("Live market analyzer", style=MaterialTheme.typography.titleLarge) }
                item { Text("Live signals only. No Quotex login or automatic order placement.") }
                item {
                    OutlinedTextField(value=key,onValueChange={key=it},label={Text("Twelve Data API key")},modifier=Modifier.fillMaxWidth())
                }
                item { SelectBox("Pair", pair, pairs) { pair=it } }
                item { SelectBox("Chart", "${frame}s", frames.map { if(it<60) "${it}s" else "${it/60}m" }) { v ->
                    frame = when(v) {"15s"->15;"30s"->30;"1m"->60;"2m"->120;"3m"->180;else->300}
                }}
                item { SelectBox("Expiry", exp, expiry) { exp=it } }
                item {
                    Button(
                        onClick = {
                            if(!live) {
                                feed.connect(key, pair)
                                live=true
                            } else {
                                feed.close(); live=false; status="OFFLINE"
                            }
                        },
                        modifier=Modifier.fillMaxWidth()
                    ) { Text(if(live) "Disconnect LIVE" else "Connect LIVE") }
                }
                item {
                    Card {
                        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                            Text(status)
                            Text(lastPrice?.let{"%.6f".format(it)} ?: "—", style=MaterialTheme.typography.headlineMedium)
                            Spacer(Modifier.height(10.dp))
                            Text(
                                when(result.signal){Signal.UP->"UP ↑";Signal.DOWN->"DOWN ↓";Signal.NO_TRADE->"NO TRADE"},
                                style=MaterialTheme.typography.displaySmall
                            )
                            Text("Confidence: ${result.confidence}%")
                            Text(result.reason)
                        }
                    }
                }
                item { Text("Candles: ${candles.size} • Feed: Twelve Data WebSocket") }
                item { Text("Important: this feed is a general market feed; Quotex may use its own quote stream. Validate signals in Demo before any real-money use.") }
            }
        }
    }
}

@Composable
fun SelectBox(label:String,value:String,options:List<String>,onChange:(String)->Unit){
    var open by remember{mutableStateOf(false)}
    Box{
        OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){Text("$label: $value")}
        DropdownMenu(expanded=open,onDismissRequest={open=false}){
            options.forEach{DropdownMenuItem(text={Text(it)},onClick={onChange(it);open=false})}
        }
    }
}
