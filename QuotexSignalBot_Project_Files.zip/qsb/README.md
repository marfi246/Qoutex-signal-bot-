# QuotexSignalBot Live v2

This Android Studio project is a live market-signal prototype.

## Real-time feed
It uses Twelve Data's documented WebSocket quote feed:
wss://ws.twelvedata.com/v1/quotes/price?apikey=YOUR_API_KEY

The app accepts the API key locally and subscribes to the selected forex pair. It aggregates incoming ticks into 15s/30s/1m/2m/3m/5m candles and calculates:
- EMA 9 / EMA 21
- RSI 14
- Rate of Change
- UP / DOWN / NO TRADE
- confidence score

## Practice first
Use the app in Demo/backtest mode before risking money. The signal engine is a heuristic, not a guaranteed prediction.

## Quotex compatibility
This app does NOT log into Quotex, does NOT ask for a Quotex password, and does NOT place Quotex orders. Quotex can use its own quote stream, so a third-party market feed can differ from the price shown in Quotex.

## Build
Open this folder in Android Studio and run the `app` configuration.

For real-time forex WebSocket access, create a Twelve Data API key and enter it in the app. Twelve Data documents WebSocket access and subscription syntax; availability/limits depend on the plan.
